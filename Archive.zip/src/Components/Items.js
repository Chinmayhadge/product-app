function Items() {
    return (
        <div className="Prod-form">

            <h1>Add New ITEMS</h1>
            <input type="text" placeholder="product name"></input>
            <input type="text" placeholder="product Type"></input>
            <input type="Number" placeholder="product Price"></input>
            <input type="file" placeholder="product img"></input>
            <button>Submit</button>
        </div>

    )

}

export default Items;